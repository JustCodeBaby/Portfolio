// Uncomment the next line to use precompiled headers
#include "pch.h"
// Uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
#include <vector>
#include <stdexcept>

// the global test environment setup and tear down
class Environment : public ::testing::Environment {
public:
    ~Environment() override {}

    void SetUp() override {
        srand(time(nullptr));
    }

    void TearDown() override {}
};

// create our test class to house shared data between tests
class CollectionTest : public ::testing::Test {
protected:
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override {
        collection.reset(new std::vector<int>);
    }

    void TearDown() override {
        collection->clear();
        collection.reset(nullptr);
    }

    void add_entries(int count) {
        assert(count > 0);
        for (auto i = 0; i < count; ++i) {
            collection->push_back(rand() % 100);
        }
    }
};

// Test that a collection is empty when created.
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull) {
    ASSERT_TRUE(collection);
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate) {
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

// Test adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector) {
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);

    add_entries(1);

    ASSERT_FALSE(collection->empty());
    ASSERT_EQ(collection->size(), 1);
}

// Test adding five values to the collection
TEST_F(CollectionTest, CanAddFiveValuesToVector) {
    add_entries(5);
    ASSERT_EQ(collection->size(), 5);
}

// Test that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxSizeIsGreaterThanOrEqualToSize) {
    std::vector<int>::size_type initialSize = collection->size();

    ASSERT_GE(collection->max_size(), initialSize);

    add_entries(1);
    ASSERT_GE(collection->max_size(), collection->size());

    add_entries(4);
    ASSERT_GE(collection->max_size(), collection->size());

    add_entries(5);
    ASSERT_GE(collection->max_size(), collection->size());
}

// Test that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CapacityIsGreaterThanOrEqualToSize) {
    ASSERT_GE(collection->capacity(), collection->size());

    add_entries(1);
    ASSERT_GE(collection->capacity(), collection->size());

    add_entries(4);
    ASSERT_GE(collection->capacity(), collection->size());

    add_entries(5);
    ASSERT_GE(collection->capacity(), collection->size());
}

// Test resizing increases the collection
TEST_F(CollectionTest, ResizingIncreasesCollection) {
    collection->resize(10);
    ASSERT_EQ(collection->size(), 10);
}

// Test resizing decreases the collection
TEST_F(CollectionTest, ResizingDecreasesCollection) {
    add_entries(10);
    collection->resize(5);
    ASSERT_EQ(collection->size(), 5);
}

// Test resizing decreases the collection to zero
TEST_F(CollectionTest, ResizingDecreasesCollectionToZero) {
    add_entries(10);
    collection->resize(0);
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

// Test clear erases the collection
TEST_F(CollectionTest, ClearErasesCollection) {
    add_entries(10);
    collection->clear();
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

// Test erase(begin, end) erases the collection
TEST_F(CollectionTest, EraseBeginEndErasesCollection) {
    add_entries(10);
    collection->erase(collection->begin(), collection->end());
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

// Test reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, ReserveIncreasesCapacityNotSize) {
    auto initialCapacity = collection->capacity();
    collection->reserve(20);
    ASSERT_GE(collection->capacity(), initialCapacity);
    ASSERT_EQ(collection->size(), 0);
}

// Test that std::out_of_range exception is thrown when calling at() with an index out of bounds (negative test)
TEST_F(CollectionTest, ThrowsExceptionWhenAccessingOutOfBounds) {
    ASSERT_THROW(collection->at(0), std::out_of_range);
    add_entries(5);
    ASSERT_THROW(collection->at(10), std::out_of_range);
}

// Custom positive test: Check if vector contains a specific value after adding
TEST_F(CollectionTest, ContainsAddedValue) {
    add_entries(5);
    collection->push_back(42);
    auto it = std::find(collection->begin(), collection->end(), 42);
    ASSERT_NE(it, collection->end());
}

// Custom negative test: Access negative index using at() (invalid)
TEST_F(CollectionTest, AccessNegativeIndexThrowsException) {
    add_entries(5);
    ASSERT_THROW(collection->at(-1), std::out_of_range);
}

